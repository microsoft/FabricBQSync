import pytest

def test_case1():
    assert 1 == 1