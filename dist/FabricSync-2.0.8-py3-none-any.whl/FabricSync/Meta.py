class Version():
    CurrentVersion = "2.0.8"